// Initialize an empty array for problems
let problems = [];

// Load CSV and parse the data
function loadProblemsFromCSV(csvFilePath) {
    return new Promise((resolve, reject) => {
        Papa.parse(csvFilePath, {
            download: true,
            header: true,
            complete: (results) => {
                console.log("CSV Loaded:", results.data); // Debugging line
                problems = results.data.map(problem => {
                    const acceptanceValue = problem.Acceptance && typeof problem.Acceptance === 'string'
                        ? parseFloat(problem.Acceptance.replace('%', ''))
                        : 0; // Default to 0 if missing or not a string
                    return {
                        id: parseInt(problem.Question_no), // Parse Question_no to an integer
                        question: problem.Question,
                        acceptance: acceptanceValue,
                        isPremium: problem.isPremium === 'true',
                        difficulty: difficultyMapping(problem.Difficulty),
                        link: problem.Question_link
                    };
                });
                
                resolve(problems);
            },
            error: (error) => {
                console.error("Parsing Error:", error); // Debugging line
                reject(error);
            }
        });
    });
}

// Map difficulty to numeric values for easier processing
function difficultyMapping(difficulty) {
    switch (difficulty) {
        case "Easy": return 1;
        case "Medium": return 2;
        case "Hard": return 3;
        default: return 2; // Default to Medium if unknown
    }
}

// Mock function to fetch solved problems for a user
function getUserSolvedProblems(leetcodeId) {
    return [1, 3]; // Mock data: IDs of solved problems
}

// KNN recommendation function
function calculateDistance(problem1, problem2) {
    const diffDifficulty = Math.pow(problem1.difficulty - problem2.difficulty, 2);
    const diffAcceptance = Math.pow(problem1.acceptance - problem2.acceptance, 2);
    return Math.sqrt(diffDifficulty + diffAcceptance);
}

function recommendProblemsForUser(leetcodeId, k) {
    const solvedProblems = new Set(getUserSolvedProblems(leetcodeId));
    const unsolvedProblems = problems.filter(problem => !solvedProblems.has(problem.id));

    // Define user preferences (adjust as necessary)
    const userPreference = { difficulty: 2, acceptance: 40.0 }; // Example user preferences

    const distances = unsolvedProblems.map(problem => ({
        ...problem,
        distance: calculateDistance(userPreference, problem)
    }));

    return distances.sort((a, b) => a.distance - b.distance).slice(0, k);
}

// Main function to load CSV and get recommendations
function generateRecommendations() {
    const csvFilePath = 'Leetcode_Questions.csv'; // Ensure this path is correct
    loadProblemsFromCSV(csvFilePath).then(() => {
        const leetcodeId = "ravena_s"; // Replace with actual user ID if available
        const recommendedProblems = recommendProblemsForUser(leetcodeId, 3);

        const outputDiv = document.getElementById("output");
        outputDiv.innerHTML = "<h2>Recommended Problems:</h2>";
        recommendedProblems.forEach(problem => {
            outputDiv.innerHTML += `<p>${problem.question} - Difficulty: ${problem.difficulty}, Acceptance: ${problem.acceptance}%</p>`;
        });
    }).catch(error => {
        console.error("Error loading CSV:", error);
    });
}

// Ensure DOM is loaded before calling generateRecommendations
window.addEventListener("DOMContentLoaded", generateRecommendations);
